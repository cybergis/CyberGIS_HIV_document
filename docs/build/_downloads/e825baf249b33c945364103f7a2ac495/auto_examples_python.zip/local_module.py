"""
Local module
============

This example demonstrates how local modules can be imported.
This module is imported in the example 'Plotting the exponential function'
(``plot_exp.py``).
"""

N = 100
